function previewFile() {
    
 var preview = document.querySelector('#fto');
  var file    = document.querySelector('#img').files[0];
  var reader  = new FileReader();

  reader.onloadend = function () {
    preview.src = reader.result;
  }

  if (file) {
    reader.readAsDataURL(file);
  } else {
    preview.src = "";
  }
}

function previewFile2() {
    
 var preview = document.querySelector('#fto2');
  var file    = document.querySelector('#img2').files[0];
  var reader  = new FileReader();

  reader.onloadend = function () {
    preview.src = reader.result;
  }

  if (file) {
    reader.readAsDataURL(file);
  } else {
    preview.src = "";
  }
}

function previewFile3() {
    
 var preview = document.querySelector('#fto3');
  var file    = document.querySelector('#img3').files[0];
  var reader  = new FileReader();

  reader.onloadend = function () {
    preview.src = reader.result;
  }

  if (file) {
    reader.readAsDataURL(file);
  } else {
    preview.src = "";
  }
}

function previewFile4() {
    
 var preview = document.querySelector('#fto4');
  var file    = document.querySelector('#img4').files[0];
  var reader  = new FileReader();

  reader.onloadend = function () {
    preview.src = reader.result;
  }

  if (file) {
    reader.readAsDataURL(file);
  } else {
    preview.src = "";
  }
}


